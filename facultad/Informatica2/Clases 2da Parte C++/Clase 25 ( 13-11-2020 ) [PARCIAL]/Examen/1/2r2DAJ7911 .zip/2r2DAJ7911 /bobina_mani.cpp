///////*FORMUAL w^2 = 1/LC
//////*w = 2pi*frec
////// *L = henrios  (bobina)
///// *C = Capacitor en uf 
///// Para calcular L = 1 /(w^2*C)		 	 	

#include<iostream>
#include<cstdlib>
#include<math.h>
#include<iomanip> ///setprecision(n de presicion)
#define pi 3.141592

using namespace std;


/////primera sobrecarga//////
void Induccion(int capa, int frec)
{ 

float w = 2	* pi * frec;	
float l;

l = 1/ ((w * w) * capa);

cout <<"\n El valor de la Inductancia es: "<< l <<" nH"<< endl <<endl;

cout <<"\n Introduzca el valor del capa [como valor entero]: ";
cin >>capa; 


}//fin de la funcion


////Funcion Induccion sobrecargada//////
void Induccion(float condes, int frec)
{ 


float w = 2	* pi * frec;	
float l;

l = 1/ ((w * w) * condes);

cout <<"\n El valor de la Inductancia es: "<< l <<" H"<< endl <<endl;


}//fin de funcion

	

int main(int argc, char* argv[])
{

int capa, frec;
float condes;



cout <<"\n Introduzca el valor del capa [como valor entero]: ";
cin >>capa; 
cout <<"\n Introduzca la Frecuencia [Como valor entero]: ";
cin >>frec; 
cout <<"\n Introduzca el valor del capa [como notacion cientifica ej: 1e-6]: ";
cin >>condes;

Induccion(condes, frec); //segunda Carga
Induccion(capa, frec); //Primera carga


return EXIT_SUCCESS;
}



